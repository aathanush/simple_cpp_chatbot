#ifndef _VOICE_H
#define _VOICE_H
#include <iostream>
#include<string>
#include<Windows.h>
using namespace std;
class Voice {
public:
    void say(string phrase){
     string command = "espeak \""+phrase+"\""; 
    cout << phrase << endl;  // Textually output phrase 
    const char* charCommand = command.c_str();
    system(charCommand);  
}    // Used to textually and audibly communicate a phrase
};
#endif
