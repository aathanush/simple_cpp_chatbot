#ifndef _LEARNER_H
#define _LEARNER_H
#include<string>
#include<algorithm>
#include <iostream>
#include <fstream>
#include "Voice.h"

using namespace std;

class Learner {
public:
    string respond(string phrase){
    fstream memory;
    memory.open("memory.txt", ios::in);    // Open the memory file for input
    std:: transform(phrase.begin(), phrase.end(), phrase.begin(), ::tolower);
    // Search through the file until the end is reached
    while( !memory.eof() ){    // While not at end of file
        string identifier;
        getline(memory,identifier);    // Get next phrase
        
        if ((phrase)=="bye"){
            voice.say("Okay, bye!");
            return "bye";
        }
        if(identifier == phrase){    // Is it the phrase we are looking for
            string response;
            getline(memory,response);   // If so, get the response
            voice.say(response);   // Textually and audibly output the response!
            return "go";    // Leave the function
        }
    }

    memory.close();    // Looks like we couldn't find the phrase in memory. Close the file!
    memory.open("memory.txt", ios::out | ios::app);    // Now open for output, and append at end of file
    memory << endl<< phrase << endl;    // Record initial phrase in memory
    voice.say(phrase);   // Repeat the phrase the user entered
    memory.close();
    memory.open("memory.txt", ios::out | ios::app); 
    string userResponse;
    cout << "YOU: ";
    getline(cin, userResponse); 
    cout<<endl<<userResponse<<endl;   // Get the ideal response
    memory << userResponse << endl;    // Write the ideal response to memory
    memory.close();    // Close the file!
    return "go";
}

/*
    This function simply communicates a phrase textually and audibly
*/
void say(string phrase){
    this->voice.say(phrase);
}
    Voice voice;    // The learner's voice that will audibly communicate a response
};

#endif
